#include <stdbool.h>

// Input signal names and sources
float RNI1, RNI2, RNI3, RNI4; // Neutron flux rate positive change signals from 4 measuring channels
bool RNI1_Q, RNI2_Q, RNI3_Q, RNI4_Q; // Quality bits for each signal
bool RNI_RST; // External reset signal

// Output signal names
bool RT1; // Shutdown signal sent to dedicated device A
bool RT2; // Shutdown signal sent to shutdown circuit breaker

// Function prototypes
void update_quality_bits(void);
bool hysteresis_comparator(float signal, float high_threshold, float low_threshold);
void RS_flip_flops(bool *RS_outputs, bool S_input, bool R_input);
void majority_vote(bool *output1, bool *output2, bool *inputs, bool *quality_bits);

int main() {
    bool RS_outputs[4] = {false, false, false, false};
    bool majority_vote_inputs[4];

  update_quality_bits();

    for(int i = 0; i < 4; i++) {
        float RNI_signal = (i == 0) ? RNI1 : (i == 1) ? RNI2 : (i == 2) ? RNI3 : RNI4;
        majority_vote_inputs[i] = hysteresis_comparator(RNI_signal, 100, 95);
    }

    for(int i = 0; i < 4; i++) {
        RS_flip_flops(&RS_outputs[i], majority_vote_inputs[i], RNI_RST);
    }

    majority_vote(&RT1, &RT2, RS_outputs, (bool[]){RNI1_Q, RNI2_Q, RNI3_Q, RNI4_Q});

    return 0;
}

// Update the quality bits for each signal based on their range
void update_quality_bits() {
    float RNI_signals[] = {RNI1, RNI2, RNI3, RNI4};
    bool *quality_bits[] = {&RNI1_Q, &RNI2_Q, &RNI3_Q, &RNI4_Q};

    for(int i = 0; i < 4; i++) {
        if (RNI_signals[i] < 10 || RNI_signals[i] > 10000) {
            *quality_bits[i] = false;
        }
    }
}

// Hysteresis comparator function
bool hysteresis_comparator(float signal, float high_threshold, float low_threshold) {
    static bool output = false;

    if (signal >= high_threshold) {
        output = true;
    } else if (signal <= low_threshold) {
        output = false;
    }

    return output;
}

// RS flip-flop function
void RS_flip_flops(bool *RS_output, bool S_input, bool R_input) {
    if (S_input) {
        *RS_output = true;
    } else if (R_input) {
        *RS_output = false;
    }
}

// Majority vote function with degraded functionality depending on quality bits
void majority_vote(bool *output1, bool *output2, bool *inputs, bool *quality_bits) {
    int valid_count = 0;
    int threshold = 2;

    for (int i = 0; i < 4; i++) {
        if (quality_bits[i]) {
            valid_count++;
        }
    }

    if (valid_count < 2) {
        threshold = 1;
    }

    int active_inputs = 0;
    for (int i = 0; i < 4; i++) {
        if (inputs[i] && quality_bits[i]) {
            active_inputs++;
        }
    }

    if (active_inputs >= threshold) {
        *output1 = true;
        *output2 = true;
    } else {
        *output1 = false;
        *output2 = false;
    }
}
