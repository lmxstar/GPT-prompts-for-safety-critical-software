#include <stdbool.h>
#include <stdint.h>

// Input signals
typedef struct {
    float RNI[4];
    bool RNI_Q[4];
    bool RNI_RST;
} ReactorNuRate Inputs;

// Output signals
typedef struct {
    bool RT1;
    bool RT2;
} ReactorNuRate Outputs;

// Hysteresis comparator function
static bool hysteresis_comparator(float value, float high_threshold, float low_threshold, bool *state) {
    if (value >= high_threshold) {
        *state = true;
    } else if (value <= low_threshold) {
        *state = false;
    }
    return *state;
}

// RS Flip-Flop function
static bool rs_flip_flop(bool set, bool reset, bool *state) {
    if (set) {
        *state = true;
    } else if (reset) {
        *state = false;
    }
    return *state;
}

// 4-2 Vote function
static bool four_two_vote(bool inputs[4], bool quality_bits[4]) {
    int good_inputs = 0;
    int active_inputs = 0;

    for (int i = 0; i < 4; ++i) {
        if (quality_bits[i]) {
            good_inputs++;
            if (inputs[i]) {
               active_inputs++;
            }
        }
    }

    if (good_inputs >= 2 && active_inputs * 2 >= good_inputs) {
        return true;
    }
    return false;
}

// Top-level function
void reactor_neu_rate(const ReactorNuRate Inputs *inputs, ReactorNuRate Outputs *outputs) {
    bool action_signals[4] = {0};
    bool hysteresis_states[4] = {0};
    bool flip_flop_states[4] = {0};

    // Process input signals
    for (int i = 0; i < 4; ++i) {
        // Check if the input signal is out of range
        if (inputs->RNI[i] < 10.0f || inputs->RNI[i] > 10000.0f) {
            inputs->RNI_Q[i] = false;
        }

        // Calculate action signals using the hysteresis comparator
        action_signals[i] = hysteresis_comparator(inputs->RNI[i], 100.0f, 95.0f, &hysteresis_states[i]);
    }

    // Process RS flip-flops
    for (int i = 0; i < 4; ++i) {
        rs_flip_flop(action_signals[i], inputs->RNI_RST, &flip_flop_states[i]);
    }

 // Calculate output signals using the 4-2 vote function
    outputs->RT1 = four_two_vote(flip_flop_states, inputs->RNI_Q);
    outputs->RT2 = outputs->RT1;
}

