#include <stdbool.h>
#include <stdint.h>

// Constants for cruise control system
#define SPEED_MIN 30.0f          // Minimum cruise speed
#define SPEED_MAX 150.0f         // Maximum cruise speed
#define SPEED_INC 2.5f           // Speed increment/decrement for quick accel/decel
#define KP 8.113f                // Proportional gain
#define KI 0.5f                  // Integral gain
#define THROTTLE_SAT_MAX 45.0f   // Maximum throttle saturation value
#define PEDALS_MIN 3.0f          // Minimum pedal value to detect pedal press

// CruiseState enum for different cruise control states
typedef enum
{
    CRUISE_OFF,       // Cruise control is off
    CRUISE_ON,        // Cruise control is on and active
    CRUISE_STDBY,     // Cruise control is on standby
    CRUISE_INT        // Cruise control is interrupted by brake pedal
} CruiseState;

// Car driving control function calculates throttle command based on speed error and integral
static float car_driving_control(float speed_error, float *integral, bool is_on, bool is_saturated)
{
    if (!is_on)
    {
        // Reset integral when cruise control is off
        *integral = 0.0f;
        return 0;
    }

    if (!is_saturated)
    {
        // Update integral if throttle is not saturated
        *integral += speed_error;
    }

    // Calculate control output using proportional and integral gains
    float output = (KP * speed_error) + (KI * (*integral));
    return output;
}

// Cruise speed management function updates cruise speed based on user inputs
static float cruise_speed_management(float current_speed, CruiseState state, bool set, bool quick_accel, bool quick_decel)
{
    static float cruise_speed = 0.0f; // Maintain the current cruise speed

    if ((state != CRUISE_ON) && (state != CRUISE_STDBY) && (state != CRUISE_INT))
    {
        return cruise_speed;
    }
    // Update cruise speed according to user inputs
    if (set)
    {
        cruise_speed = current_speed; // Set cruise speed to current speed
    }
    else if (quick_accel && (cruise_speed + SPEED_INC) <= SPEED_MAX)
    {
        cruise_speed += SPEED_INC; // Increase cruise speed
    }
    else if (quick_decel && (cruise_speed - SPEED_INC) >= SPEED_MIN)
    {
        cruise_speed -= SPEED_INC; // Decrease cruise speed
    }

    return cruise_speed;
}

// Pedals pressed detection function checks if a pedal is pressed based on its value
static bool is_pedal_pressed(float pedal_value)
{
    return pedal_value > PEDALS_MIN; // Returns true if pedal value is greater than the minimum threshold
}

// Cruise control behavior function determines the new cruise control state based on provided inputs
static CruiseState cruise_control_behavior(CruiseState current_state, bool on, bool off, bool resume, bool brake_pressed, bool accel_pressed, float speed)
{
    CruiseState new_state = current_state; // Initialize new_state with current_state

    // Update cruise control state based on inputs
    if (off)
    {
        new_state = CRUISE_OFF;
    }
    else if (on)
    {
        new_state = CRUISE_ON;
    }
    else if (current_state == CRUISE_ON)
    {
        if (accel_pressed || (speed < SPEED_MIN) || (speed > SPEED_MAX))   
        {
            new_state = CRUISE_STDBY;
        }
    }    

    else if ((current_state == CRUISE_STDBY) && (!accel_pressed) && (speed >= SPEED_MIN) && (speed <= SPEED_MAX))
    {
        new_state = CRUISE_ON;
    }
    else if (brake_pressed)
    {
        new_state = CRUISE_INT;
    }
    else if (current_state == CRUISE_INT && resume)
    {
        if (!accel_pressed && (speed >= SPEED_MIN) && (speed <= SPEED_MAX))
        {
            new_state = CRUISE_ON;
        }
        else
        {
            new_state = CRUISE_STDBY;
        }
    }

    return new_state;
}

// Top-level function for Cruise Control
void cruise_control(const bool CC_INR_01, const bool CC_INR_02, const bool CC_INR_03, const bool CC_INR_04, const bool CC_INR_05,
                    const float CC_INR_06, const float CC_INR_07, const float CC_INR_08,float *CC_OUTR_01, bool *CC_OUTR_02, CruiseState *CC_OUTR_03)
{
    // Manage cruise control behavior based on inputs
    CruiseState new_state = cruise_control_behavior(*CC_OUTR_03, CC_INR_01, !CC_INR_01, CC_INR_02, is_pedal_pressed(CC_INR_07), is_pedal_pressed(CC_INR_06), CC_INR_08);

    // Manage cruise speed based on inputs and current cruise control state
    float cruise_speed = cruise_speed_management(CC_INR_08, new_state, CC_INR_03, CC_INR_05, CC_INR_04);

    // Calculate speed error between the current speed and desired cruise speed
    float speed_error = cruise_speed - CC_INR_08;

    // Determine if throttle is saturated (reached maximum limit)
    bool is_saturated = *CC_OUTR_02 >= THROTTLE_SAT_MAX;

    // Calculate throttle command based on speed error, integral, cruise control state, and saturation
    static float integral = 0.0f;
    float throttle_cmd = car_driving_control(speed_error, &integral, new_state == CRUISE_ON, is_saturated);

    // Update output signals with calculated values
    *CC_OUTR_01 = cruise_speed;   // Output cruise speed
    *CC_OUTR_02 = throttle_cmd;   // Output throttle command
    *CC_OUTR_03 = new_state;      // Output updated cruise control state
}
