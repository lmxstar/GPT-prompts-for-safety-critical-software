#include <stdio.h>

#define CHANNELS 4
#define THRESHOLD 10

typedef struct {
    int powerSignal;
    int resetSignal;
} RSFlipFlop;

typedef struct {
    int qualityBit;
    int stopSignal;
} VoterInput;

VoterInput voterInputs[CHANNELS];
RSFlipFlop rsFlipFlop;

void processPowerSignal(int channel, int signal) {
    if (signal > THRESHOLD) {
        rsFlipFlop.powerSignal = 1;
    }
    voterInputs[channel].stopSignal = rsFlipFlop.powerSignal;
}

void processResetSignal(int signal) {
    rsFlipFlop.resetSignal = signal;
}

void processVoterInputs() {
    int goodInputs = 0;
    int badInputs = 0;
    for (int i = 0; i < CHANNELS; i++) {
        if (voterInputs[i].qualityBit == 1) {
            goodInputs++;
        } else {
            badInputs++;
        }
    }

    if (goodInputs >= 2) {
        // Output two stop signals
        printf("Output two stop signals\n");
    } else if (goodInputs == 1) {
        // Output one stop signal
        printf("Output one stop signal\n");
    } else {
        // All signals are bad, output action signal
        printf("Output action signal\n");
    }
}

int main() {
    // Initialize RS flip flop
    rsFlipFlop.powerSignal = 0;
    rsFlipFlop.resetSignal = 0;

    // Initialize voter inputs
    for (int i = 0; i < CHANNELS; i++) {
        voterInputs[i].qualityBit = 1;
        voterInputs[i].stopSignal = 0;
    }

    // Process signals
    for (int i = 0; i < CHANNELS; i++) {
        processPowerSignal(i, i * 3); // Example power signals
    }
    processResetSignal(1); // Example reset signal

    // Process voter inputs
    processVoterInputs();

    return 0;
}
