#include <stdbool.h>
#include <stddef.h>

// Input signal names and sources
typedef enum {
    CC_OFF,
    CC_ON,
    CC_RESUME,
    CC_SET,
    CC_QUICK_DECEL,
    CC_QUICK_ACCEL
} CC_Commands;

typedef struct {
   CC_Commands command;
    float speed;
    float accel;
    float brake;
} CC_Input;

// Output signal names
typedef struct {
    float cruise_speed;
    bool throttle_cmd;
    enum { CS_OFF, CS_ON, CS_STDBY, CS_INT } cruise_state;
} CC_Output;

// Function prototypes
void cruise_control(CC_Input input, CC_Output *output);
void cruise_speed_management(CC_Input input, CC_Output *output);
void car_driving_control(CC_Input input, CC_Output *output);
void pedals_pressed_detection(CC_Input input, CC_Output *output);

int main() {
    CC_Input input;
    CC_Output output;

    // Update input signals here

    cruise_control(input, &output);

    return 0;
}

// Main cruise control function
void cruise_control(CC_Input input, CC_Output *output) {
    cruise_speed_management(input, output);
    car_driving_control(input, output);
    pedals_pressed_detection(input, output);
}

// Cruise speed management functionality
void cruise_speed_management(CC_Input input, CC_Output *output) {
    const float SpeedMin = 30.0;
    const float SpeedMax = 150.0;
    const float SpeedInc = 2.5;

    if (output->cruise_state == CS_ON || output->cruise_state == CS_STDBY || output->cruise_state == CS_INT) {
        if (input.command == CC_SET) {
            output->cruise_speed = input.speed;
        } else if (input.command == CC_QUICK_ACCEL) {
            output->cruise_speed = (output->cruise_speed + SpeedInc <= SpeedMax) ? output->cruise_speed + SpeedInc : SpeedMax;
        } else if (input.command == CC_QUICK_DECEL) {
            output->cruise_speed = (output->cruise_speed - SpeedInc >= SpeedMin) ? output->cruise_speed - SpeedInc : SpeedMin;
        }
    }
}

// Car driving control functionality
void car_driving_control(CC_Input input, CC_Output *output) {
    const float Kp = 8.113;
    const float Ki = 0.5;
    const float ThrottleSatMax = 45.0;

    // Implement the proportional and integral algorithm here, using Kp and Ki factors

    // Limit the throttle command to ThrottleSatMax to ensure comfort during automatic regulation
    if (output->throttle_cmd > ThrottleSatMax) {
        output->throttle_cmd = ThrottleSatMax;
    }
}

// Pedals pressed detection functionality
void pedals_pressed_detection(CC_Input input, CC_Output *output) {
    const float PedalsMin = 3.0;

    bool accel_pressed = input.accel > PedalsMin;
    bool brake_pressed = input.brake > PedalsMin;

    // Update CruiseState based on pedal presses and CC commands
    switch (input.command) {
        case CC_OFF:
            output->cruise_state = CS_OFF;
            break;
        case CC_ON:
            output->cruise_state = CS_ON;
            break;
        case CC_RESUME:
            if (!accel_pressed && (input.speed >= 30.0 && input.speed <= 150.0)) {
                output->cruise_state = CS_ON;
            } else {
                output->cruise_state = CS_STDBY;
            }
            break;
        default:
            break;
    }

    if (brake_pressed) {
        output->cruise_state = CS_INT;
    } else if (accel_pressed || input.speed < 30.0 || input.speed > 150.0) {
        output->cruise_state = CS_STDBY;
    } else if (!accel_pressed && (input.speed >= 30.0 && input.speed <= 150.0)) {
        output->cruise_state = CS_ON;
    }
}
